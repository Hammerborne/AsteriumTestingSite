﻿using UMod.Shared;
using UnityEngine;

namespace UMod.Exporter
{
    [CreateAssetMenu(fileName = "ExporterResources", menuName = "Tools/Editor Resources/Exporter Resources")]
    public class UModExporterResources : EditorResources
    {
        // Public
        public Texture2D uModLogoSmall;
        public Texture2D uModLogoLarge;
        public Texture2D defaultModToolsLogoSmall;
        public Texture2D defaultModToolsLogoLarge;
        public Texture2D newModIcon;
        public Texture2D aboutIcon;
        public Texture2D settingsIcon;

        public Texture2D documentationImage;
        public Texture2D scriptingReferenceImage;
        public Texture2D companyImage;
        public Texture2D uModImage;
        public Texture2D errorIcon;
        public Texture2D exporterSettingsIcon;
        public Texture2D exporterHelpIcon;
    }
}
