﻿using UMod.Shared;

namespace UMod.Exporter
{
    internal sealed class UModExporterVersion : ModVersion<UModExporterVersion>
    {
        // Properties
        public override int MajorVersion
        {
            get { return 2; }
        }

        public override int MinorVersion
        {
            get { return 1; }
        }

        public override int RevisionVersion
        {
            get { return 0; }
        }
    }
}
