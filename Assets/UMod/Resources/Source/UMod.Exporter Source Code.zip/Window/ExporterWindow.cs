﻿using System;
using Trivial.ImGUI;
using UMod.BuildEngine;
using UMod.BuildEngine.Export;
using UMod.BuildEngine.ModTools;
using UMod.Shared;
using UnityEditor;
using UnityEngine;

namespace UMod.Exporter
{
    /// <summary>
    /// uMod exporter window.
    /// </summary>
    [UModToolsWindow]
    public sealed class ExporterWindow : UModWindow
    {
        // Internal
        internal static bool lastBuildAndRun = false;

        // Private
        private UModExporterResources resources = null;
        private ModToolsSettings toolSettings = null;
        private ExportSettings settings = null;
        private string currentBuildStatus = "unknown";
        private bool startBuild = false;
        private bool buildAndRun = false;
        private bool buildAndRunEnabled = false;
        
        // Methods
        /// <summary>
        /// Called on window open.
        /// </summary>
        protected override void OnEnable()
        {
            base.OnEnable();

            // Load the last result
            currentBuildStatus = EditorPrefs.GetString("umod.exporter.lastbuildresult", "unknown");
            
            // Load the settings
            resources = UModExporterResources.LoadPackageData<UModExporterResources>();
            toolSettings = ModToolsSettings.Active.Load();

            // Load the settings
            settings = ExportSettings.Active.LoadOrCreate(FileUtil.GetProjectRelativePath(UModUtil.UModInstallDirectory.ToString()));

            // Check if build and run is enabled
            buildAndRunEnabled = settings.ValidateExecutable();

            // Add update listener
            EditorApplication.update += () =>
            {
                // Check for build flag
                if (startBuild == true)
                {
                    startBuild = false;
                    LaunchBuild(buildAndRun, OnFocus);
                }
            };
        }

        /// <summary>
        /// Called when window gains focus.
        /// </summary>
        public void OnFocus()
        {
            // Load the last result
            currentBuildStatus = EditorPrefs.GetString("umod.exporter.lastbuildresult", "unknown");

            // Check if build and run is enabled
            buildAndRunEnabled = settings.ValidateExecutable();

            // Render the window
            Repaint();
        }

        /// <summary>
        /// Called when the window header content should be displayed.
        /// </summary>
        /// <param name="content">The header content information</param>
        protected override void OnHeaderContentImGUI(HeaderContent content)
        {
            ImGUILayout.BeginLayout(ImGUILayoutType.Vertical);
            {
                ImGUILayout.Space(15);

                Texture2D modToolsTexture = toolSettings.ToolsIconLarge;

                // Revert to default umod
                if (modToolsTexture == null)
                    modToolsTexture = resources.defaultModToolsLogoLarge;

                // Show the image
                ImGUI.SetNextSize(130, 38);
                ImGUI.SetNextTexture(modToolsTexture);
                ImGUILayout.Image();

                ImGUILayout.Space(10);
            }
            ImGUILayout.EndLayout();
        }

        /// <summary>
        /// Called when the window should be displayed.
        /// </summary>
        public override void OnImGUI()
        {
            base.OnImGUI();

            string displayVersion = "v" + toolSettings.ToolsVersion;

            // Take into account long version numbers
            float requiredWidth = EditorStyles.miniLabel.CalcSize(new GUIContent(displayVersion)).x;

            // Push enabled
            ImGUI.PushEnabledVisualState(false);
            {
                // Tools version
                ImGUI.SetNextStyle(ImGUIStyle.MiniLabel);
                ImGUI.SetNextPosition(Screen.width - requiredWidth, Screen.height - 36);
                ImGUI.SetNextSize(80, 16);
                ImGUI.Label(displayVersion);
            }
            ImGUI.PopVisualState();
        }

        /// <summary>
        /// Called when the main window content should be displayed.
        /// </summary>
        protected override void OnContentImGUI()
        {
            titleContent.text = "Mod Export";

            minSize = new Vector2(240, 106);

            // Help icons
            ImGUI.SetNextHeight(14);
            ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
            {
                // Push to right
                ImGUILayout.Space();

                // Settings icon
                ImGUI.SetNextSize(12, 12);
                ImGUI.SetNextStyle(ImGUIStyle.None);
                ImGUI.SetNextTexture(resources.exporterSettingsIcon);
                ImGUI.SetNextTooltip("Open the mod export settings window");
                if (ImGUILayout.Button(string.Empty) == true)
                {
                    // Show settings window
                    SettingsWindow.ShowWindow<SettingsWindow>();
                }

                ImGUILayout.Space(4);

                // Help icon
                ImGUI.SetNextSize(12, 12);
                ImGUI.SetNextStyle(ImGUIStyle.None);
                ImGUI.SetNextTexture(resources.exporterHelpIcon);
                ImGUI.SetNextTooltip("Open the mod tools help window");
                if (ImGUILayout.Button(string.Empty) == true)
                {
                    // Show help window
                    HelpWindow.ShowWindow<HelpWindow>();
                }

                ImGUILayout.Space(4);

                // Developer icon
                ImGUI.SetNextSize(14, 14);
                ImGUI.SetNextStyle(ImGUIStyle.None);
                ImGUI.SetNextTexture(toolSettings.ToolsIconSmall ? toolSettings.ToolsIconSmall : resources.defaultModToolsLogoSmall);
                ImGUI.SetNextTooltip("Go to the developers website");
                if (ImGUILayout.Button(string.Empty) == true)
                {
                    // Open developer website
                    Application.OpenURL(toolSettings.DeveloperWebsiteURL);
                }
            }
            ImGUILayout.EndLayout();
            

            // Active target layout
            ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
            {
                // Active target
                ImGUI.SetNextWidth(labelWidth - 50);
                ImGUILayout.Label("Active Mod:");
                
                // Popup menu
                if (settings.ExportProfiles.Length == 0)
                {
                    ImGUI.PushEnabledVisualState(false);

                    // Show popup field
                    if (toolSettings.Options.AllowMultipleModsPerProject == true)
                    {
                        // Show an error popup
                        ImGUI.PopupItem("<Configuration Required!>");
                        ImGUILayout.Popup(0);
                    }
                    else
                    {
                        // Show configuration label
                        ImGUILayout.Label("<Configuration Required!>");
                    }

                    ImGUI.PopVisualState();
                }
                else
                {
                    // Show popup field
                    if (toolSettings.Options.AllowMultipleModsPerProject == true)
                    {
                        foreach (ExportProfileSettings item in settings.ExportProfiles)
                        {
                            string itemName = item.ModName;

                            // Check for error
                            if (string.IsNullOrEmpty(itemName) == true)
                                itemName = "<Configuration Required!>";

                            // Add the popup item
                            ImGUI.PopupItem(itemName);
                        }

                        // Display the popup
                        int index = ImGUILayout.Popup(settings.ActiveExportProfileIndex);

                        // Update active profile
                        if (index != settings.ActiveExportProfileIndex)
                        {
                            // Update selected export profile
                            settings.SetActiveExportProfile(index);

                            // Update mod references
                            ReferenceAssemblyLoader.LoadReferencedAssemblies();
                        }
                    }
                    else
                    {
                        // Show mod name label
                        ImGUILayout.Label(settings.ActiveExportProfile.ModName);
                    }
                }
            }
            ImGUILayout.EndLayout(); // End active target


            // Last build result
            ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
            {
                // Label
                ImGUI.SetNextWidth(labelWidth - 50);
                ImGUI.SetNextTooltip("The result of the last attempted mod export");
                ImGUILayout.Label("Last Result:");

                // Field
                ImGUILayout.Label(currentBuildStatus);
            }
            ImGUILayout.EndLayout();
        }

        /// <summary>
        /// Called when the window footer content should be displayed.
        /// </summary>
        protected override void OnFooterContentImGUI()
        {
            // Check for invalid settings
            if (settings.ExportProfileCount == 0 || settings.ValidateRequiredValues() == false)
            {
                // Configure
                ImGUI.SetNextTooltip("Configuration is required before you can export a mod");
                ImGUI.SetNextWidth(100);
                ImGUI.SetNextHeight(24);
                if (ImGUILayout.Button("Configure") == true)
                {
                    // Show the settings window
                    SettingsWindow.ShowWindow<SettingsWindow>();
                }
            }
            else
            {
                // Build mod
                ImGUI.SetNextTooltip("Start building the mod");
                ImGUI.SetNextWidth(100);
                ImGUI.SetNextHeight(24);
                if (ImGUILayout.Button("Build Mod!") == true)
                {
                    buildAndRun = false;
                    startBuild = true;

                    // Update status
                    currentBuildStatus = "In Progress!";

                    // Repaint the window to trigger the GUI again
                    Repaint();
                }

                // Build and run mod
                ImGUI.SetNextTooltip("Start building the mod and launch in game when complete" + ((settings.ValidateExecutable() == false) ? " (Requires Setup)" : string.Empty));
                ImGUI.SetNextWidth(100);
                ImGUI.SetNextHeight(24);
                ImGUI.PushEnabledVisualState(buildAndRunEnabled);

                if (ImGUILayout.Button("Build and Run!") == true)
                {
                    buildAndRun = true;
                    startBuild = true;

                    // Update status
                    currentBuildStatus = "In Progress!";

                    // Repaint the window to trigger the GUI again
                    Repaint();
                }

                ImGUI.PopVisualState();
            }
        }

        /// <summary>
        /// Start a mod build.
        /// </summary>
        /// <param name="buildAndRun">Should the mod be launched in the target game when successfully built</param>
        /// <param name="onCompleted">Callback to invoke when the build is done regardless of success</param>
        public static void LaunchBuild(bool buildAndRun, Action onCompleted = null)
        {
            // Store the build and run flag
            lastBuildAndRun = buildAndRun;

            // Show export settings window when settings are invalid
            Action invalidSettingsCallback = () =>
            {
                // Missing required fields
                SettingsWindow.ShowWindow(true);
            };

            // Try to load settings
            ExportSettings settings = ExportSettings.Active.Load();
            ModBuildResult result = null;

            // Start build
            if(buildAndRun == true)
            {
                // Validate build and run settings
                if (settings.ValidateExecutable() == false)
                {
                    Log.Warning(typeof(ExporterWindow), "Build and Run has not been enabled. Go to 'Tools/uMod Exporter/Export Settings' to setup build and run");
                    return;
                }

                // Start build and run
                result = ModToolsUtil.StartBuildAndRun(settings, invalidSettingsCallback);
            }
            else
            {
                // Start build
                result = ModToolsUtil.StartBuild(settings, invalidSettingsCallback);
            }

            if(result != null)
            {
                // Store success value
                EditorPrefs.SetString("umod.exporter.lastbuildresult", result.Successful ?
                    "successful" :
                    "Failed");
            }

            // Trigger callback
            if (onCompleted != null)
                onCompleted();
        }
    }
}
