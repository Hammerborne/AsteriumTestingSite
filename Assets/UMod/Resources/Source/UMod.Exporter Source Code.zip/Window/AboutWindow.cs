﻿using UMod.Shared;
using Trivial.ImGUI;
using UMod.BuildEngine.ModTools;
using UMod.BuildEngine;
using UnityEngine;

namespace UMod.Exporter
{
    /// <summary>
    /// uMod exporter about window.
    /// </summary>
    [UModToolsWindow]
    public sealed class AboutWindow : UModWindow
    {
        // Private
        private ModToolsSettings toolSettings = null;
        private UModExporterResources resources = null;

        // Methods
        /// <summary>
        /// Called on window open.
        /// </summary>
        protected override void OnEnable()
        {
            // Load resources
            resources = UModExporterResources.LoadPackageData<UModExporterResources>();

            // Setup title header content
            Content.Title = "About";
            Content.Icon = resources.aboutIcon;

            // Load the tool settings
            toolSettings = ModToolsSettings.Active.Load();
        }

        /// <summary>
        /// Called when the main window content should be displayed.
        /// </summary>
        protected override void OnContentImGUI()
        {
            // Window title
            minSize = maxSize = new Vector2(400, 310);
            titleContent.text = "Tools Info";

            // Header
            ImGUI.SetNextStyle(ImGUIStyle.BoldLabel);
            ImGUILayout.Label("Mod Tools");

            ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
            {
                // Mod tools icon
                ImGUILayout.BeginLayout(ImGUILayoutType.Vertical);
                {
                    // Spacer
                    ImGUILayout.Space(10);

                    // Icon
                    ImGUI.SetNextSize(26, 26);
                    ImGUI.SetNextTexture(toolSettings.ToolsIconSmall ? toolSettings.ToolsIconSmall : resources.defaultModToolsLogoSmall);
                    ImGUILayout.Image();
                }
                ImGUILayout.EndLayout();

                // Mod tools info
                ImGUILayout.BeginLayout(ImGUILayoutType.Vertical);
                {
                    // Mod tools version
                    ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                    {
                        // Label
                        ImGUI.SetNextWidth(labelWidth - 20);
                        ImGUILayout.Label("Tools Package:");

                        // Field
                        ImGUILayout.Label(string.Format("{0}, {1}", toolSettings.ToolsName, toolSettings.ToolsVersion));
                    }
                    ImGUILayout.EndLayout();

                    // Mod tools version
                    ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                    {
                        // Label
                        ImGUI.SetNextWidth(labelWidth - 20);
                        ImGUILayout.Label("Target Game:");

                        // Field
                        ImGUILayout.Label(string.Format("{0}, {1}", toolSettings.GameName, toolSettings.GameVersion));
                    }
                    ImGUILayout.EndLayout();

                    // Developer
                    ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                    {
                        // Label
                        ImGUI.SetNextWidth(labelWidth - 20);
                        ImGUILayout.Label("Developer:");

                        // Field
                        ImGUILayout.Label(toolSettings.DeveloperName);
                    }
                    ImGUILayout.EndLayout();
                }
                ImGUILayout.EndLayout();
            }
            ImGUILayout.EndLayout();


            // Header
            ImGUILayout.Space(10);
            ImGUI.SetNextStyle(ImGUIStyle.BoldLabel);
            ImGUILayout.Label("uMod 2.0");


            ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
            {
                // Mod tools icon
                ImGUILayout.BeginLayout(ImGUILayoutType.Vertical);
                {
                    // Small spacer
                    ImGUILayout.Space(10);

                    // Icon
                    ImGUI.SetNextSize(26, 26);
                    ImGUI.SetNextTexture(resources.uModLogoSmall);
                    ImGUILayout.Image();
                }
                ImGUILayout.EndLayout();

                // uMod info
                ImGUILayout.BeginLayout(ImGUILayoutType.Vertical);
                {
                    // Build engine version
                    ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                    {
                        // Label
                        ImGUI.SetNextWidth(labelWidth - 20);
                        ImGUILayout.Label("Build Engine:");

                        // Field
                        ImGUILayout.Label(UModBuildEngineVersion.VersionString);
                    }
                    ImGUILayout.EndLayout();

                    // Exporter version
                    ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                    {
                        // Label
                        ImGUI.SetNextWidth(labelWidth - 20);
                        ImGUILayout.Label("Exporter:");

                        // Field
                        ImGUILayout.Label(UModExporterVersion.VersionString);
                    }
                    ImGUILayout.EndLayout();

                    // Unity
                    ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                    {
                        // Label
                        ImGUI.SetNextWidth(labelWidth - 20);
                        ImGUILayout.Label("Unity Requirements:");

                        // Field
                        ImGUILayout.Label(toolSettings.TargetUnityVersion);
                    }
                    ImGUILayout.EndLayout();
                }
                ImGUILayout.EndLayout();
            }
            ImGUILayout.EndLayout();
        }
    }
}
