﻿using System;
using Trivial.ImGUI;
using UMod.BuildEngine;
using UMod.BuildEngine.ModTools;
using UMod.Shared;
using UnityEditor;
using UnityEngine;

namespace UMod.Exporter
{
    /// <summary>
    /// uMod exporter help window.
    /// </summary>
    [UModToolsWindow]
    public sealed class HelpWindow : UModWindow
    {
        // Private
        private const int iconSize = 50;

        private UModExporterResources resources = null;
        private ModToolsSettings toolSettings = null;
        private GUIStyle iconTextStyle = null;

        // Properties
        /// <summary>
        /// Get the icon width scaled based on the window size.
        /// </summary>
        public float DynamicIconWidth
        {
            get { return Screen.width / 2.8f; }
        }

        // Methods
        /// <summary>
        /// Called on window open.
        /// </summary>
        protected override void OnEnable()
        {
            base.OnEnable();

            // Load the resources
            resources = UModExporterResources.LoadPackageData<UModExporterResources>();

            // Load the tool settings
            toolSettings = toolSettings.Load();
        }

        /// <summary>
        /// Called when the window header content should be displayed.
        /// </summary>
        /// <param name="content">The header content information</param>
        protected override void OnHeaderContentImGUI(HeaderContent content)
        {
            ImGUILayout.BeginLayout(ImGUILayoutType.Vertical);
            {
                ImGUILayout.Space(15);

                // Image
                ImGUI.SetNextSize(130, 38);
                ImGUI.SetNextTexture(resources.defaultModToolsLogoLarge);
                ImGUILayout.Image();

                ImGUILayout.Space(10);
            }
            ImGUILayout.EndLayout();
        }

        /// <summary>
        /// Called when the main window content should be displayed.
        /// </summary>
        protected override void OnContentImGUI()
        {
            // Show help window
            titleContent.text = "Mod Help";

            // Make sure styles are valid
            LoadIconStyles();

            // Help label
            ImGUI.SetNextStyle(ImGUIStyle.WrappedLabel);
            ImGUILayout.Label(string.Format("Welcome to {0}, v{1} modding tools. These tools allow you to create and build modded content for the target game '{2}, v{3}'. Take a look at the following topics to get started!",
                toolSettings.ToolsName, toolSettings.ToolsVersion, toolSettings.GameName, toolSettings.GameVersion));

            // Small space
            ImGUILayout.Space(20);

            bool narrowLayout = position.width < 390;

            // Link images
            if(narrowLayout == false)
                ImGUILayout.BeginLayout(ImGUILayoutType.HorizontalCentered);
            {
                // Documentation grid icon
                ImGUI.SetNextWidth(DynamicIconWidth);
                ImGUILayout.BeginLayout(ImGUILayoutType.Vertical);
                {
                    ImGUILayout.BeginLayout(ImGUILayoutType.HorizontalCentered);
                    {
                        // uMod website
                        ImGUI.SetNextTooltip("Take a look at the online documentation to get started");
                        ImGUI.SetNextTexture(resources.documentationImage);
                        ImGUI.SetNextSize(iconSize, iconSize);
                        ImGUILayout.LinkImage(toolSettings.OnlineDocumentationURL, ScaleMode.ScaleToFit);
                    }
                    ImGUILayout.EndLayout();

                    // Text
                    ImGUI.SetNextStyle(iconTextStyle);
                    ImGUILayout.Label("Take a look at the modding documentation");
                }
                ImGUILayout.EndLayout();

                ImGUILayout.Space();

                // Developer website grid icon
                ImGUI.SetNextWidth(DynamicIconWidth);
                ImGUILayout.BeginLayout(ImGUILayoutType.Vertical);
                {
                    ImGUILayout.BeginLayout(ImGUILayoutType.HorizontalCentered);
                    {
                        // Dev website
                        ImGUI.SetNextTooltip("Take a look at the online scripting reference");
                        ImGUI.SetNextTexture(resources.scriptingReferenceImage);
                        ImGUI.SetNextSize(iconSize, iconSize);
                        ImGUILayout.LinkImage(toolSettings.OnlineScriptingReferenceURL, ScaleMode.ScaleToFit);
                    }
                    ImGUILayout.EndLayout();

                    // Text
                    ImGUI.SetNextStyle(iconTextStyle);
                    ImGUILayout.Label("Take a look at the mod scripting reference for available API's");
                }
                ImGUILayout.EndLayout();
            }
            if(narrowLayout == false)
                ImGUILayout.EndLayout();

            // Small space
            ImGUILayout.Space(10);
            ImGUILayout.Space();

            // Link images - second row
            if (narrowLayout == false)
                ImGUILayout.BeginLayout(ImGUILayoutType.HorizontalCentered);
            {
                // Developer website grid icon
                ImGUI.SetNextWidth(DynamicIconWidth);
                ImGUILayout.BeginLayout(ImGUILayoutType.Vertical);
                {
                    ImGUILayout.BeginLayout(ImGUILayoutType.HorizontalCentered);
                    {
                        // Documentation
                        ImGUI.SetNextTooltip("Open the developers website");
                        ImGUI.SetNextTexture(resources.companyImage);
                        ImGUI.SetNextSize(iconSize, iconSize);
                        ImGUILayout.LinkImage(toolSettings.DeveloperWebsiteURL, ScaleMode.ScaleToFit);
                    }
                    ImGUILayout.EndLayout();

                    // Text
                    ImGUI.SetNextStyle(iconTextStyle);
                    ImGUILayout.Label("Go to the developers website");
                }
                ImGUILayout.EndLayout();

                // ####### UNUSED icon button
                //// Small space
                //ImGUILayout.Space();

                //// Another grid icon
                //ImGUI.SetNextWidth(DynamicIconWidth);
                //ImGUILayout.BeginLayout(ImGUILayoutType.Vertical);
                //{
                //    ImGUILayout.BeginLayout(ImGUILayoutType.HorizontalCentered);
                //    {
                //        // Scripting reference
                //        ImGUI.SetNextTooltip("Take a look at the uMod 2.0 scripting reference for a detailed overview of the API");
                //        ImGUI.SetNextTexture(resources.uModImage);
                //        ImGUI.SetNextSize(iconSize, iconSize);
                //        ImGUILayout.LinkImage("http://umod.trivialinteractive.co.uk/scriptingreference", ScaleMode.ScaleToFit);
                //    }
                //    ImGUILayout.EndLayout();

                //    // Text
                //    ImGUI.SetNextStyle(iconTextStyle);
                //    ImGUILayout.Label("Some text here");
                //}
                //ImGUILayout.EndLayout();
            }
            if (narrowLayout == false)
                ImGUILayout.EndLayout();


            
            // Push to botton
            ImGUILayout.Space();

            string menuPath = null;

            // Search for the menu entry to open this window
            foreach (ModToolsOptions.ModToolsMenuEntry menuEntry in toolSettings.Options.MenuEntries)
            {
                if (menuEntry.MenuAction == ModToolsOptions.ModToolsMenuAction.ShowWindow)
                {
                    if ((Type)menuEntry.WindowType == typeof(HelpWindow))
                    {
                        menuPath = toolSettings.Options.MenuRoot + "/" + menuEntry.MenuEntryName;
                        menuPath = menuPath.Replace("/", " -> ");
                        break;
                    }
                }
            }

            // Re-open hint
            if (menuPath != null)
            {
                ImGUI.SetNextStyle(ImGUIStyle.WrappedLabel);
                ImGUILayout.Label("You can access this help window at any time from the following menu: " + menuPath);
            }
        }

        /// <summary>
        /// Called when the window footer content should be displayed.
        /// </summary>
        protected override void OnFooterContentImGUI()
        {
            // Close button
            ImGUILayout.BeginLayout(ImGUILayoutType.HorizontalCentered);
            {
                ImGUI.SetNextTooltip("Dismiss this window");
                ImGUI.SetNextWidth(100);
                ImGUI.SetNextHeight(24);
                if (ImGUILayout.Button("Got It!") == true)
                {
                    // Close this window
                    Close();
                }
            }
            ImGUILayout.EndLayout();
        }

        private void LoadIconStyles()
        {
            if(iconTextStyle == null)
            {
                iconTextStyle = new GUIStyle(EditorStyles.wordWrappedLabel);
                iconTextStyle.alignment = TextAnchor.MiddleCenter;
            }
        }
    }
}
