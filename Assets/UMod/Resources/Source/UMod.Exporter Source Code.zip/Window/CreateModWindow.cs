﻿using System;
using Trivial.ImGUI;
using UMod.Shared;
using UnityEngine;
using UnityEditor;
using System.IO;
using UMod.BuildEngine;

namespace UMod.Exporter
{
    [Flags]
    internal enum CreateModInvalidSettings
    {
        None = 0,
        InvalidName = 1,
        InvalidPath = 2,
    }

    /// <summary>
    /// uMod new mod creation window.
    /// </summary>
    [UModToolsWindow]
    public sealed class CreateModWindow : UModWindow
    {
        // Private
        private UModExporterResources resources = null;
        private GUIStyle errorStyle = null;
        ModCreate.ValidateSetting validated = ModCreate.ValidateSetting.Valid;

        private bool makeActive = true;
        private string modName = "My New Mod";
        private string createFolder = "Assets";

        // Methods
        /// <summary>
        /// Called on window open.
        /// </summary>
        protected override void OnEnable()
        {
            base.OnEnable();

            // Load resources
            resources = UModExporterResources.LoadPackageData<UModExporterResources>();

            // Window title
            titleContent.text = "Create Mod";

            // Setup header title content
            Content.Title = "Create New Mod";
            Content.Icon = resources.newModIcon;
        }

        /// <summary>
        /// Called when the main window content should be displaye.
        /// </summary>
        protected override void OnContentImGUI()
        {
            // Check for valid settings
            validated = ModCreate.ValidatesModCreateParamters(createFolder, modName);

            // Set active build target
            ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
            {
                // Label
                ImGUI.SetNextTooltip("If enabled, the current export settings will be modified so that the new mod will be the active build target");
                ImGUI.SetNextWidth(labelWidth);
                ImGUILayout.Label("Set as Active build Target:");

                // Toggle
                makeActive = ImGUILayout.Toggle(makeActive);
            }
            ImGUILayout.EndLayout();

            // Mod name
            ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
            {
                // Label
                ImGUI.SetNextTooltip("The name of the mod. The name must not already exist");
                ImGUI.SetNextWidth(labelWidth);
                ImGUILayout.Label("Mod Name:");
                    
                // Field
                modName = ImGUILayout.TextField(modName);

                // Error field
                if ((validated & ModCreate.ValidateSetting.InvalidName) != 0 || 
                    (validated & ModCreate.ValidateSetting.AlreadyExists) != 0)
                    ErrorFieldImGUI();
            }
            ImGUILayout.EndLayout();

            // Create in folder
            ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
            {
                // Label
                ImGUI.SetNextTooltip("The folder to create the new mod under");
                ImGUI.SetNextWidth(labelWidth);
                ImGUILayout.Label("Create in Folder:");
                    
                // Field
                createFolder = ImGUILayout.TextField(createFolder);              

                // Browse
                ImGUI.SetNextTooltip("Select via the folder dialog window");
                ImGUI.SetNextWidth(40);
                if(ImGUILayout.Button("...") == true)
                {
                    // Show the dialog
                    string result = EditorUtility.OpenFolderPanel("Select folder", createFolder, string.Empty);

                    // Update the folder
                    if(string.IsNullOrEmpty(result) == false)
                    {
                        createFolder = result;

                        // Release focus of the text field
                        ImGUI.UnfocusAll();
                    }
                }

                // Error field
                if ((validated & ModCreate.ValidateSetting.InvalidFolder) != 0)
                    ErrorFieldImGUI();
            }
            ImGUILayout.EndLayout();
            

            // Push to bottom
            ImGUILayout.Space();

            // Hint error
            if((validated & ModCreate.ValidateSetting.AlreadyExists) != 0)
            {
                ImGUILayout.HelpBox("It looks like a mod with the same name already exists in the specified folder");
            }

            // Push to bottom
            ImGUILayout.Space();
        }

        /// <summary>
        /// Called when the window footer content should be displayed.
        /// </summary>
        protected override void OnFooterContentImGUI()
        {
            ImGUI.PushEnabledVisualState(validated == ModCreate.ValidateSetting.Valid);

            // Create button
            ImGUI.SetNextWidth(100);
            ImGUI.SetNextHeight(24);
            ImGUI.SetNextTooltip("Create the new mod using the above settings");            
            if (ImGUILayout.Button("Create Mod!") == true)
            {
                // Get the full mod path
                string fullPath = Path.Combine(createFolder, modName);

                // Create the new mod
                ModCreate.OnModCreated += (ModCreateArgs args) =>
                {
                    // Close this window
                    Close();
                };

                // Create the default mod structure
                ModCreate.CreateNewMod(fullPath, makeActive);
            }

            ImGUI.PopVisualState();
        }

        private void ErrorFieldImGUI()
        {
            // Create style if necessary
            if (errorStyle == null)
            {
                errorStyle = new GUIStyle(GUI.skin.label);
                errorStyle.padding = new RectOffset(0, 0, 6, 5);
            }

            // Spacer
            ImGUILayout.Space(-3);

            // Icon
            ImGUI.SetNextStyle(errorStyle);
            ImGUI.SetNextSize(15, 15);
            ImGUI.SetNextTexture(resources.errorIcon);
            ImGUI.SetNextTooltip("This field is not valid");
            ImGUILayout.Image();
        }
    }
}
