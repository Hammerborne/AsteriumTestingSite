﻿using System;
using Trivial.ImGUI;
using UnityEngine;
using UnityEditor;
using UMod.Shared;
using System.IO;
using UMod.BuildEngine;
using UMod.BuildEngine.Export;
using UMod.BuildEngine.ModTools;

namespace UMod.Exporter
{
    /// <summary>
    /// uMod exporter settings window.
    /// </summary>
    [UModToolsWindow]
    public sealed class SettingsWindow : UModWindow
    {
        // Private
        private ModToolsSettings toolSettings = null;
        private UModExporterResources resources = null;
        private ExportSettings settings = null;
        private GUIStyle errorStyle = null;
        private Vector2 scroll = Vector2.zero;
        private bool startBuild = false;
        private bool fromBuild = false;
        private int selectedTab = 0;
        private int selectedReference = -1;

        // Methods
        /// <summary>
        /// Show the exporter settings window.
        /// </summary>
        /// <param name="fromBuild">Was the window opened by the exporter as a result of invalid export settings</param>
        /// <param name="openTab">Open the settings to the specified tab</param>
        public static void ShowWindow(bool fromBuild, int openTab = 0)
        {
            SettingsWindow instance = ImEditorWindow.ShowWindow<SettingsWindow>();

            instance.fromBuild = fromBuild;
            instance.selectedTab = openTab;
        }

        /// <summary>
        /// Called on window open.
        /// </summary>
        protected override void OnEnable()
        {
            base.OnEnable();

            minSize = new Vector2(360, 200);

            // Load tools
            toolSettings = ModToolsSettings.Active.Load();

            // Load resources
            resources = UModExporterResources.LoadPackageData<UModExporterResources>();

            // Setup header title
            Content.Title = "Export Settings";
            Content.Icon = resources.settingsIcon;

            // Load the settings
            settings = ExportSettings.Active;
            settings.Load();

            // Add update listener
            EditorApplication.update += () =>
            {
                // Check for build flag
                if(startBuild == true)
                {
                    startBuild = false;

                    // Close the settings window and run the build
                    Close();
                    ExporterWindow.LaunchBuild(ExporterWindow.lastBuildAndRun);
                }
            };
        }

        /// <summary>
        /// Called on window closed.
        /// </summary>
        protected override void OnDisable()
        {
            base.OnDisable();

            // Save settings
            settings.Save();
        }

        /// <summary>
        /// Called when window content should be displayed.
        /// </summary>
        protected override void OnContentImGUI()
        {
            // Check for lost settings
            if(settings == null)
            {
                Close();
                return;
            }

            titleContent.text = "Mod Settings";

            ImGUI.ToolbarItem("Mod");
            ImGUI.ToolbarItem("Build");
            ImGUI.ToolbarItem("Build and Run");

            // Centered toolbal
            ImGUILayout.BeginLayout(ImGUILayoutType.HorizontalCentered);
            {
                // Show the toolbal
                selectedTab = ImGUILayout.Toolbar(selectedTab);
            }
            ImGUILayout.EndLayout();

            // Small space
            ImGUILayout.Space(10);
            
            ImGUILayout.BeginLayout(ImGUILayoutType.ScrollView);
            {
                // Display based on tab
                if (selectedTab == 0) GUIModTab();
                if (selectedTab == 1) GUIBuildTab();
                if (selectedTab == 2) GUIBuildAndRunTab();
            }
            ImGUILayout.EndLayout();

            // Push to bottom
            ImGUILayout.Space();

            
            // Coninute build button
            if (fromBuild == true)
            {
                // Spacer
                ImGUILayout.Separator();

                ImGUI.SetNextStyle(ImGUIStyle.TextField);
                ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                {
                    bool validExportSettings = settings.ValidateRequiredValues();
                                        
                    if (validExportSettings == false)
                    {
                        // Help box
                        ImGUI.SetNextStyle(ImGUIStyle.WrappedLabel);
                        ImGUILayout.Label("You will be able to continue the build once you have filled in the required fields");
                    }

                    // Push to right
                    ImGUILayout.Space();
                    
                    ImGUI.PushEnabledVisualState(validExportSettings == true);

                    // Continue button
                    ImGUI.SetNextTooltip("Resume the current build");
                    ImGUI.SetNextWidth(120);
                    ImGUI.SetNextHeight(30);

                    if (ImGUILayout.Button("Continue Build!") == true)
                    {
                        startBuild = true;

                        // Render thw window
                        Repaint();
                    }

                    ImGUI.PopVisualState();
                }
                ImGUILayout.EndLayout();
                

                // Catch mouse events
                if (Event.current.type == EventType.MouseUp)
                {
                    selectedReference = -1;

                    // Force a repaint
                    Repaint();
                }
            }
        }

        private void GUIModTab()
        {
            if (toolSettings.Options.AllowMultipleModsPerProject == true)
            {
                // Display the active profile
                GUIModTabActiveProfile();
            }
            else
            {
                // Require a valid export profile
                if (settings.ActiveExportProfile == null)
                    settings.CreateNewExportProfile(true);
            }

            // Contextual mod information
            if (settings.ExportProfiles.Length > 0)
            {
                GUIModTabModInformation();
                GUIModTabModExport();

                // Display references section
                if(toolSettings.Options.AllowModReferences == true)
                    GUIModTabModReferences();
            }

            // Deselect reference
            if(Event.current.type == EventType.MouseUp)
            {
                // Use the event
                selectedReference = -1;
                Event.current.Use();
            }
        }

        private void GUIBuildTab()
        {
            // Group box
            ImGUILayout.BeginLayout(ImGUILayoutType.Vertical);
            {
                // Title
                ImGUI.SetNextStyle(ImGUIStyle.BoldLabel);
                ImGUILayout.Label("Exporter Settings");

                // Log level
                ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                {
                    // Label
                    ImGUI.SetNextTooltip("The amount of detail that is logged to the console during export");
                    ImGUI.SetNextWidth(labelWidth);
                    ImGUILayout.Label("Log Level:");

                    // Popup
                    settings.LogLevel = (LogLevel)ImGUILayout.EnumPopup(settings.LogLevel);
                }
                ImGUILayout.EndLayout();

                // Optimize for
                ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                {
                    // Label
                    ImGUI.SetNextTooltip("Used to trade off between build time and build size");
                    ImGUI.SetNextWidth(labelWidth);
                    ImGUILayout.Label("Optimize for:");

                    // Popup
                    settings.OptimizeMode = (BuildOptimizeMode)ImGUILayout.EnumPopup(settings.OptimizeMode);
                }
                ImGUILayout.EndLayout();
                
                // Clear console on build
                ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                {
                    // Label
                    ImGUI.SetNextTooltip("Should the Unity console be cleared before starting a build");
                    ImGUI.SetNextWidth(labelWidth);
                    ImGUILayout.Label("Clear Console On Build:");

                    // Toggle
                    settings.ClearConsoleOnBuild = ImGUILayout.Toggle(settings.ClearConsoleOnBuild);
                }
                ImGUILayout.EndLayout();

                // Show output directory
                ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                {
                    // Label
                    ImGUI.SetNextTooltip("Should the output location of the mod be shown upon a successful build");
                    ImGUI.SetNextWidth(labelWidth);
                    ImGUILayout.Label("Show Output Directory:");

                    // Toggle
                    settings.ShowOutputDirectory = ImGUILayout.Toggle(settings.ShowOutputDirectory);
                }
                ImGUILayout.EndLayout();
            }
            ImGUILayout.EndLayout();
        }

        private void GUIBuildAndRunTab()
        {
            // Group box
            ImGUILayout.BeginLayout(ImGUILayoutType.Vertical);
            {
                // Title
                ImGUI.SetNextStyle(ImGUIStyle.BoldLabel);
                ImGUILayout.Label("Target Game Settings");

                // Game Executable
                ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                {
                    // Label
                    ImGUI.SetNextWidth(labelWidth);
                    ImGUILayout.Label("Game Executable Path:");

                    // Text field
                    settings.CommandLineExecutable = ImGUILayout.TextField(settings.CommandLineExecutable);

                    // Browse button
                    ImGUI.SetNextTooltip("Select the executable path using the file dialog window");
                    ImGUI.SetNextWidth(40);
                    if(ImGUILayout.Button("...") == true)
                    {
                        // Show the dialog window
                        string result = EditorUtility.OpenFolderPanel("Select game executable", settings.CommandLineExecutable, string.Empty);

                        // Check for valid result
                        if (string.IsNullOrEmpty(result) == false)
                        {
                            // Update the folder
                            settings.CommandLineExecutable = result;

                            // Render the window
                            Repaint();
                        }
                    }
                }
                ImGUILayout.EndLayout();

                // Help field
                ImGUILayout.HelpBox("Build and Run allows you to quickly export and test a mod in the target game. To enabe build and run functionality you need to add the game executable to the above path and specify the command line calling convention used. As long as the target game supports command line launching of mods, you will be able to build and run modded content in a single click");
            }
            ImGUILayout.EndLayout();
        }


        #region ModTabSections
        private void GUIModTabActiveProfile()
        {
            // Group box
            ImGUILayout.BeginLayout(ImGUILayoutType.Vertical);
            {
                ImGUI.PushEnabledVisualState(fromBuild == false || settings.ExportProfiles.Length == 0);

                // Title
                ImGUI.SetNextStyle(ImGUIStyle.BoldLabel);
                ImGUILayout.Label("Export profile");

                // Active profile layout
                ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                {
                    // Active profile
                    ImGUI.SetNextTooltip("Switch the active export target");
                    ImGUI.SetNextWidth(labelWidth);
                    ImGUILayout.Label("Active Profile:");

                    // Popup menu
                    if (settings.ExportProfiles.Length == 0)
                    {
                        ImGUI.PushEnabledVisualState(false);

                        // Show an error popup
                        ImGUI.PopupItem("<Configuration Required!>");
                        ImGUILayout.Popup(0);

                        ImGUI.PopVisualState();
                    }
                    else
                    {
                        // Profile items
                        foreach (ExportProfileSettings item in settings.ExportProfiles)
                        {
                            string itemName = item.ModName;

                            // Check for error
                            if (string.IsNullOrEmpty(itemName) == true)
                                itemName = "<Configuration Required!>";

                            // Add the popup item
                            ImGUI.PopupItem(itemName);
                        }

                        // Display the popup
                        int index = ImGUILayout.Popup(settings.ActiveExportProfileIndex);

                        // Update active profile
                        if (index != settings.ActiveExportProfileIndex)
                        {
                            // Update selected profile
                            settings.SetActiveExportProfile(index);

                            // Refresh referenced mods for active profile
                            ReferenceAssemblyLoader.LoadReferencedAssemblies();
                        }
                    }
                }
                ImGUILayout.EndLayout();

                // Profile add remove layout
                ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                {
                    // Push to right
                    ImGUILayout.Space();

                    // Add button
                    ImGUI.SetNextTooltip("Add new export profile");
                    ImGUI.SetNextWidth(40);

                    if (ImGUILayout.Button("+") == true)
                    {
                        // Add a new profile
                        settings.CreateNewExportProfile(true);

                        // Refresh referenced mods for active profile
                        ReferenceAssemblyLoader.LoadReferencedAssemblies();

                        // Render the window
                        Repaint();
                    }

                    ImGUI.PushEnabledVisualState(settings.ExportProfiles.Length > 0 && fromBuild == false);

                    // Remove button
                    ImGUI.SetNextTooltip("Remove current export profile");
                    ImGUI.SetNextWidth(40);

                    if (ImGUILayout.Button("-") == true)
                    {
                        // Get the active profile
                        ExportProfileSettings active = settings.ActiveExportProfile;

                        // Check for error
                        if (active == null)
                            return;

                        // Delete the profile
                        settings.DeleteExportProfile(active);

                        // Refresh referenced mods for active profile
                        ReferenceAssemblyLoader.LoadReferencedAssemblies();

                        // Render the window
                        Repaint();
                    }

                    ImGUI.PopVisualState();
                }
                ImGUILayout.EndLayout();

                // Help field
                if (settings.ExportProfiles.Length == 0)
                {
                    ImGUILayout.HelpBox("You need to create an export profile before you can export your mod. An export profile is used to specify all the mod information such as the name and version. Multiple export profiles are supported so that you can create multiple mods and simply set the active mod for export");
                }

                ImGUI.PopVisualState();
            }
            ImGUILayout.EndLayout();

            // Small space
            ImGUILayout.Space(10);
        }

        private void GUIModTabModInformation()
        {
            // Group box
            ImGUILayout.BeginLayout(ImGUILayoutType.Vertical);
            {
                // Title
                ImGUI.SetNextStyle(ImGUIStyle.BoldLabel);
                ImGUILayout.Label("Mod Information");

                // Mod name
                ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                {
                    // Label
                    ImGUI.SetNextTooltip("(Required Field) The name of the mod");
                    ImGUI.SetNextWidth(labelWidth);
                    ImGUILayout.Label("Mod Name *:");

                    // Field
                    settings.ActiveExportProfile.ModName = ImGUILayout.TextField(settings.ActiveExportProfile.ModName);

                    // Error field
                    if (settings.ValidateName() == false)
                        ErrorFieldImGUI();
                }
                ImGUILayout.EndLayout();

                // Mod version
                ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                {
                    // Label
                    ImGUI.SetNextTooltip("(Required Field) The version string for the mod in the format x.x.x where 'x' denotes a numeric value");
                    ImGUI.SetNextWidth(labelWidth);
                    ImGUILayout.Label("Mod Version (x.x.x) *:");

                    // Field
                    settings.ActiveExportProfile.ModVersion = ImGUILayout.TextField(settings.ActiveExportProfile.ModVersion);

                    // Error field
                    if (settings.ValidateVersion() == false)
                        ErrorFieldImGUI();
                }
                ImGUILayout.EndLayout();

                // Mod author
                ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                {
                    // Label
                    ImGUI.SetNextTooltip("(Optional Field) The name of the individual or team that created the mod");
                    ImGUI.SetNextWidth(labelWidth);
                    ImGUILayout.Label("Mod Author:");

                    // Field
                    settings.ActiveExportProfile.ModAuthor = ImGUILayout.TextField(settings.ActiveExportProfile.ModAuthor);
                }
                ImGUILayout.EndLayout();

                // Mod Description
                ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                {
                    // Label
                    ImGUI.SetNextTooltip("(Optional Field) A short description detailing what aspects of the game will be modified");
                    ImGUI.SetNextWidth(labelWidth);
                    ImGUILayout.Label("Mod Description:");

                    // Field
                    ImGUI.SetNextHeight(50, ImGUISizeMode.MinSize);
                    settings.ActiveExportProfile.ModDescription = ImGUILayout.TextField(settings.ActiveExportProfile.ModDescription);
                }
                ImGUILayout.EndLayout();
            }
            ImGUILayout.EndLayout();

            // Small space
            ImGUILayout.Space(10);
        }

        private void GUIModTabModExport()
        {
            // Group box
            ImGUILayout.BeginLayout(ImGUILayoutType.Vertical);
            {
                // Title
                ImGUI.SetNextStyle(ImGUIStyle.BoldLabel);
                ImGUILayout.Label("Mod Export");

                // Asset directory
                ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                {
                    // Label
                    ImGUI.SetNextTooltip("(Required Field) The mod asset folder whose contents will be exported");
                    ImGUI.SetNextWidth(labelWidth);
                    ImGUILayout.Label("Mod Asset Directory *:");

                    // Field
                    settings.ActiveExportProfile.ModAssetsPath = ImGUILayout.TextField(settings.ActiveExportProfile.ModAssetsPath);

                    // Browse
                    ImGUI.SetNextTooltip("Select the directory using the folder dialog window");
                    ImGUI.SetNextWidth(40);
                    if (ImGUILayout.Button("...") == true)
                    {
                        // Show the dialog window
                        string result = EditorUtility.OpenFolderPanel("Select asset directory", settings.ActiveExportProfile.ModAssetsPath, string.Empty);

                        // Check for valid result
                        if (string.IsNullOrEmpty(result) == false)
                        {
                            // Update the folder
                            settings.ActiveExportProfile.ModAssetsPath = result;
                            Repaint();
                        }
                    }

                    // Error field
                    if (settings.ValidateAssetPath() == false)
                        ErrorFieldImGUI();
                }
                ImGUILayout.EndLayout();

                // Export directory
                ImGUILayout.BeginLayout(ImGUILayoutType.Horizontal);
                {
                    // Label
                    ImGUI.SetNextTooltip("(Optional Field) The directory where the exported mod will be created");
                    ImGUI.SetNextWidth(labelWidth);
                    ImGUILayout.Label("Mod Export Directory:");

                    // Field
                    settings.ActiveExportProfile.ModExportPath = ImGUILayout.TextField(settings.ActiveExportProfile.ModExportPath);

                    // Browse
                    ImGUI.SetNextTooltip("Select the directory using the folder dialog window");
                    ImGUI.SetNextWidth(40);
                    if (ImGUILayout.Button("...") == true)
                    {
                        // Show the dialog window
                        string result = EditorUtility.OpenFolderPanel("Select export directory", settings.ActiveExportProfile.ModExportPath, string.Empty);

                        // Check for valid result
                        if (string.IsNullOrEmpty(result) == false)
                        {
                            // Update the folder
                            settings.ActiveExportProfile.ModExportPath = result;
                            Repaint();
                        }
                    }
                }
                ImGUILayout.EndLayout();
            }
            ImGUILayout.EndLayout();


            // Small space
            ImGUILayout.Space(10);
        }

        private void GUIModTabModReferences()
        {
            // Check for any added references
            bool hasReferences = (settings.ActiveExportProfile.ReferencedMods.Count > 0);

            // Group box
            ImGUILayout.BeginLayout(ImGUILayoutType.Vertical);
            {
                ImGUI.PushEnabledVisualState(fromBuild == false);

                // Title
                ImGUI.SetNextStyle(ImGUIStyle.BoldLabel);
                ImGUILayout.Label("Mod References");

                // Store current list count
                int count = settings.ActiveExportProfile.ReferencedMods.Count;

                // References list box
                selectedReference = ImGUILayout.Listbox<string>(null, settings.ActiveExportProfile.ReferencedMods, selectedReference, 
                () =>
                {
                    // Display dialog
                    string referencePath = EditorUtility.OpenFilePanel("Select referenced mod", string.Empty, toolSettings.ModFileExtension.Replace(".", ""));

                    // Check for valid input
                    if (string.IsNullOrEmpty(referencePath) == false)
                    {
                        // Check for circular references
                        BuildReferences references = new BuildReferences(
                            settings.ActiveExportProfile.ModName,
                            settings.ActiveExportProfile.ModVersion);

                        // Add potential reference
                        if (references.AddReferencePath(referencePath) == false)
                        {
                            ImDialog.SetNextTitle("Failed to add reference");
                            ImDialog.SetNextContent("The reference could not be added because the target mod or one of its dependencies could not be loaded");
                            ImDialog.ShowDialog();
                            return null;
                        }

                        // Check for circular dependencies
                        if (references.CheckForCircularReference() == true)
                        {
                            ImDialog.SetNextTitle("Failed to add reference");
                            ImDialog.SetNextContent("The reference could not be added because it would cause a circular dependency chain");
                            ImDialog.ShowDialog();
                            return null;
                        }

                        // Update reference engine
                        ReferenceAssemblyLoader.LoadReferencedAssemblies(true);

                        return referencePath;
                    }
                    return null;
                }, 
                (string referencePath) =>
                {
                    // Display list item
                    ImGUI.SetNextTooltip("Reference Path: " + referencePath);
                    ImGUILayout.Label(Path.GetFileName(referencePath));
                });

                // Check for removed item
                if (count < settings.ActiveExportProfile.ReferencedMods.Count)
                    ReferenceAssemblyLoader.LoadReferencedAssemblies(true);
            }
            ImGUILayout.EndLayout();
        }
        #endregion


        private void ErrorFieldImGUI()
        {
            // Create style if necessary
            if (errorStyle == null)
            {
                errorStyle = new GUIStyle(GUI.skin.label);
                errorStyle.padding = new RectOffset(0, 0, 6, 5);
            }

            // Spacer
            ImGUILayout.Space(-3);

            // Icon
            ImGUI.SetNextStyle(errorStyle);
            ImGUI.SetNextSize(15, 15);
            ImGUI.SetNextTexture(resources.errorIcon);
            ImGUI.SetNextTooltip("This field is not valid");
            ImGUILayout.Image();
        }
    }
}
